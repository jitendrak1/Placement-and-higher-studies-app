package com.singh.deepak.placement_higherstudies;

import android.content.Intent;
import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button academic_details,placement_details,higherstudies_details_entry,placed_student,higher_studies_student,logout,unplaced_student;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        academic_details =(Button)findViewById(R.id.btn_academic_details);
        placement_details =(Button)findViewById(R.id.btn_placed_student);
        higherstudies_details_entry = (Button)findViewById(R.id.btn_higher_student_entry);
        placed_student =(Button)findViewById(R.id.btn_placed);
        higher_studies_student =(Button)findViewById(R.id.btn_higher_student);
        unplaced_student = (Button)findViewById(R.id.btn_unplaced);
        logout = (Button)findViewById(R.id.btn_logout);
        academic_details.setOnClickListener(this);
        placement_details.setOnClickListener(this);
        higherstudies_details_entry.setOnClickListener(this);
        placed_student.setOnClickListener(this);
        higher_studies_student.setOnClickListener(this);
        unplaced_student.setOnClickListener(this);
        logout.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id)
        {
            case R.id.btn_academic_details:
                Intent academic = new Intent(MainActivity.this,AcademicDetails.class);
                startActivity(academic);
                break;
            case R.id.btn_placed_student:
                Intent company = new Intent(MainActivity.this,PlacementDetailEntery.class);
                startActivity(company);
                break;
            case R.id.btn_higher_student_entry:
                Intent higherentry = new Intent(MainActivity.this,HigherStudyDetails.class);
                startActivity(higherentry);
                break;
            case R.id.btn_placed:
                Intent placed = new Intent(MainActivity.this,PlacementActivity.class);
                startActivity(placed);
                break;
            case R.id.btn_higher_student:
                Intent higherStudies = new Intent(MainActivity.this,HigherStudiesActivity.class);
                startActivity(higherStudies);
                break;
            case R.id.btn_unplaced:
                Intent unplaced = new Intent(MainActivity.this,UnplacedActivity.class);
                startActivity(unplaced);
                break;
            case R.id.btn_logout:
                onLogOut();
                break;
        }

    }
    public void onLogOut()
    {
Intent logout = new Intent(MainActivity.this,LoginActivity.class);
        startActivity(logout);

    }
}
