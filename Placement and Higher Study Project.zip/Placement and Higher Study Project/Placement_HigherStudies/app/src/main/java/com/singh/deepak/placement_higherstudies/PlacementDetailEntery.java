package com.singh.deepak.placement_higherstudies;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class PlacementDetailEntery extends AppCompatActivity implements View.OnClickListener{
    EditText signup_input_name,signup_input_package;
    Button btn_signup_create_ac;
    AlertDialog.Builder builder;
    String name, rollno,pakage;
    public static final String PREFS_NAME = "MyPrefsFile";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_placement_detail_entery);
        signup_input_name = (EditText) findViewById(R.id.input_cname);
        signup_input_package = (EditText) findViewById(R.id.input_package);
        btn_signup_create_ac = (Button) findViewById(R.id.btn_company_details);
        btn_signup_create_ac.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(signup_input_name.getText().toString().equals("") || signup_input_package.getText().toString().equals(""))
        {
            builder = new AlertDialog.Builder(this);
            builder.setTitle("Somthing went wrong");
            builder.setMessage("Please fill all the fields....");
            builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
        else
        {
            name = signup_input_name.getText().toString(); SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
             rollno = prefs.getString("emailKey", null);
            pakage = signup_input_package.getText().toString();
            BackPlacementDetails backgroundTask = new BackPlacementDetails(this);
            backgroundTask.execute("register",name,rollno,pakage);
        }

    }
}
