package com.example.jampassword.nitc_tnp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    String teacherID;
    Button verify,placed,higher_studies,unplaced,teacherinfo,logout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_activity);
        initView();
    }

    private void initView() {

        verify = (Button)findViewById(R.id.btn_verify);
        placed = (Button)findViewById(R.id.btn_placed);
        higher_studies = (Button)findViewById(R.id.btn_higherStudies);
        unplaced = (Button) findViewById(R.id.btn_unplaced);
        teacherinfo = (Button)findViewById(R.id.btn_teacher_info);
        logout = (Button)findViewById(R.id.btn_logout);

        //fatch teacherID from teacher login
        teacherID = getIntent().getExtras().getString("teacherID");

        //Teacher information method
        teacherinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mintent = new Intent(MainActivity.this, TeacherInfoActivity.class);
                //send teacherID to next Activity
                mintent.putExtra("teacherID",teacherID );
                startActivity(mintent);
            }
        });

        //call verify method
        verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mintent = new Intent(MainActivity.this, VerifyButton.class);
                //send teacherID to next Activity
                mintent.putExtra("teacherID",teacherID );
                startActivity(mintent);
            }
        });

        //call placed method
        placed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mintent = new Intent(MainActivity.this, PlacementActivity.class);
                startActivity(mintent);
            }
        });

        //call higher studies method
        higher_studies.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mintent = new Intent(MainActivity.this, HigherStudiesActivity.class);
                startActivity(mintent);
            }
        });

        //call unplaced method
        unplaced.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mintent = new Intent(MainActivity.this, UnplacedActivity.class);
                startActivity(mintent);
            }
        });

        //logout method
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
